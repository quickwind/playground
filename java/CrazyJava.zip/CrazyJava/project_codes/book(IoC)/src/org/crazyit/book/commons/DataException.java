package org.crazyit.book.commons;

public class DataException extends RuntimeException {

	public DataException(String message) {
		super(message);
	}
}
