package org.crazyit.book.jdbc;

/**
 * jdbc�쳣��
 * @author yangenxiong
 *
 */
public class JDBCException extends RuntimeException {

	public JDBCException(String message) {
		super(message);
	}
}
