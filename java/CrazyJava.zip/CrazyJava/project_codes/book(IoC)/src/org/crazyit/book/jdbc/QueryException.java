package org.crazyit.book.jdbc;

public class QueryException extends RuntimeException {

	public QueryException(String message) {
		super(message);
	}
}
