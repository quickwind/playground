package org.crazyit.flashget.state;

import javax.swing.ImageIcon;

import org.crazyit.flashget.object.Resource;

public abstract class AbstractState implements TaskState {

	public void destory(Resource resouse) {
		
	}

	public void init(Resource resource) {
		
	}

}
