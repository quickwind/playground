package org.crazyit.transaction.jdbc;

public class QueryException extends RuntimeException {

	public QueryException(String message) {
		super(message);
	}
}
