package org.crazyit.ioc.context.object.interfaces;

public interface Interface2 extends Interface1 {

}
